# AI Space Shooter

A retro arcade space combat game built in Python using Pygame.

## Features
- Procedural Vector Graphics & Starfield
- Dual-laser cannons & 3-way spread powerup
- Alien enemy patrols & Mothership Boss fight
- Built-in 8-bit sound synthesizer

## Controls
- WASD: Move spaceship
- SPACEBAR: Shoot lasers
- R: Restart game